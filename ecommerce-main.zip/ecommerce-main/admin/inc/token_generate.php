<?php
$_SESSION['_token']=bin2hex(random_bytes(35));
?>