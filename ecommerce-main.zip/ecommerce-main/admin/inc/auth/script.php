<script src="assets/vendor/jquery/jquery-3.3.1.min.js"></script>
<script src="../plugins/form-validation/jquery.validate.min.js"></script>
<script src="../plugins/sweet-alert/sweetalert.min.js"></script>
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>